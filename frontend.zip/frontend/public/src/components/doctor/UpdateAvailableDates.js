import React from 'react'
import AvailableDates from './AvailableDates'

export default function UpdateAvailableDates() {
    return (
        <div >
            <div class="container">
                <div class="col-md-6">
                    <div class="card mt-4">
                        <div class="card-body" >
                            <h4 className="fontColor"><b>Update Available Dates</b></h4>
                            <hr />

                            <form className="ml-3 mt-3">

                                <div class="form-group col-sm-10">
                                    <label><b>AvailabilityDate ID</b></label><br />
                                    <input type="text" id="availabilityId"
                                        className="col-sm-12"
                                        placeholder="Availability ID"
                                        disabled
                                    />
                                </div>
                                <div class="form-group col-sm-10">
                                    <label><b>Doctor ID</b></label><br />
                                    <input type="text" id="doctorId"
                                        className="col-sm-12"
                                        placeholder="Doctor ID"
                                        disabled
                                    />
                                </div>

                                <div class="form-group col-sm-10">
                                    <label><b>From Date</b></label><br />
                                    <input type="date"
                                       
                                       className="col-sm-12"
                                        name="fromDate" required />

                                </div>
                                <div class="form-group col-sm-10">
                                    <label><b>To Date</b></label><br />
                                    <input type="date"
                                        className="col-sm-12"
                                        name="toDate" required />

                                </div>
                                <div class="form-group col-sm-10">
                                    <button type="submit" className="btn btn-block buttonFont mb-4" style={{backgroundColor:"mediumvioletred"}}>update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
