import React, { useState } from 'react'
import UpdateAvailableDates from './UpdateAvailableDates'

export default function AvailableDates() {
    const [dates , setDates] = useState(false);

    if(dates){
        return <UpdateAvailableDates/>
    }
    return (
        <div>
            <h3><b>Add Available Dates</b></h3>
            <div className="row">
                <div className="col-md-5">
                    <div className="card ">
                        <form className="ml-3 mt-3">
                            <div class="form-group col-sm-10">
                                <label><b>Doctor ID</b></label><br />
                                <input type="text" id="doctorId"
                                    className="col-sm-12"
                                    placeholder="Doctor ID"
                                    disabled
                                />
                            </div>

                            <div class="form-group col-sm-10" >
                                <label><b>From Date</b></label><br />
                                <input type="date"
                                    
                                    className="col-sm-12"
                                    name="fromDate" required />

                            </div>
                            <div class="form-group col-sm-10">
                                <label><b>To Date</b></label><br />
                                <input type="date"
                                    className="col-sm-12"
                                    name="toDate" required />

                            </div>
                            <div class="form-group col-sm-10">
                                <button type="submit" className="btn btn-block buttonFont mb-4" style={{backgroundColor:"mediumvioletred"}} >Add</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div className="col-md-7">
                    <table className="table table-striped">
                        <thead className="thead-dark">
                            <th>AvailableDates ID</th>
                            <th>Doctor ID</th>
                            <th>From Date</th>
                            <th>To Date</th>
                            <th>Update</th>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row"> 1</th>

                                <td>1</td>
                                <td>20/10/2020</td>
                                <td>23/10/2020</td>
                                <td>
                                    <a className="btn text-primary" >
                                        <i className="fas fa-pencil-alt " onClick={()=>{setDates(true)}}></i>
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
    )
}
