
import React from 'react';
import "./UpdateProfile.css"




export default function UpdateProfile() {


  return (
    <div class="container">
      <div class="col-md-6">
        <div class="card">
          <div class="card-body" >
            <form>
              <div class="form-group">
                <h4 class="header-color"><b>Upadate Profile</b> </h4>
                <hr />
              </div>
              <div class="form-group">
                        <label><b>Patient ID*</b></label><br />
                        <input type="text" value=""
                            className="form-control"
                            id="patientId" disabled />
                    </div>
              <div class="form-group">
                <label><b>Full Name*</b></label>
                <input type="text" class="form-control" id="patientName"
                  pattern="^[a-zA-Z]+$"
                  title="Only alphabets allowed" required />
              </div>
              <div class="form-group">

                <label><b>Mobile Number*</b></label>
                <input type="text" class="form-control" id="mobileNo"
                  pattern="^[6-9]{1}[0-9]{9}"
                  title="it contain 10 digits" required />

              </div>
              <div class="form-group">
                <label><b>Email address*</b></label>
                <input type="email" class="form-control" id="email" />
              </div>
              <div class="form-group">
                <label><b>Password*</b></label>
                <input type="password" class="form-control" id="password"
                  pattern="^[A-Za-z]\w{7,14}$"
                  title="password should contain one special character and minimum 8 characters"
                  required />
              </div>
              <div class="form-group form-check">
                <label id="check-box"><b>Gender :</b> &nbsp;&nbsp;</label>
                <input type="radio" name="gender" value="Male" id="check" />&nbsp;Male&nbsp;&nbsp;&nbsp;&nbsp;
  <input type="radio" name="gender" value="Female" id="check" />&nbsp;Female
 </div>

              <div class="form-group form-check">
                <label for="checkbox" id="check-box"><b>Blood group :</b> &nbsp;&nbsp;</label>
                <input type="radio" name="blood group" value="A+" id="check1" />&nbsp;A+&nbsp;&nbsp;
  <input type="radio" name="blood group" value="A-" id="check1" />&nbsp;A-&nbsp;&nbsp;
  <input type="radio" name="blood group" value="B+" id="check1" />&nbsp;B+&nbsp;&nbsp;
  <input type="radio" name="blood group" value="B-" id="check1" />&nbsp;B-&nbsp;&nbsp;
  <input type="radio" name="blood group" value="O+" id="check1" />&nbsp;O+&nbsp;
  <input type="radio" name="blood group" value="O-" id="check1" />&nbsp;O-
 </div>

              <div class="form-group">
                <label><b>Age*</b></label>
                <input type="text" class="form-control" id="age"
                  pattern="[1-9]{1}[0-9]{2}"
                  title="Age between 1 to 130" required />

              </div>
              <div class="form-group">
                <label><b>Address*</b></label><br />
                <textarea name="address" id="addres" rows="2" col="15"
                  class="form-control"
                  pattern="^[A-Za-z]\w{5,100}$"
                  title="Range between 5 to 100 " required />

              </div>
              <div class="button">

                <button class="btn btn-block" style={{ backgroundColor: "mediumvioletred" }}>Update</button>

              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}