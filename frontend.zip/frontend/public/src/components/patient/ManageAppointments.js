import React,{useState} from 'react'
import UpdateAppointment from './UpdateAppointment'


export default function ManageAppointments() { 

const [update, setUpdate] = useState(false) 

if(update){
    return <UpdateAppointment/>
}

    return (
        <div>
        <table className="table table-striped">
        <thead className="thead" style={{background: " rgb(189, 20, 127)"}}>
                   <tr>
                       <th scope="col" className="buttonFont">Patient ID</th>
                       <th scope="col" className="buttonFont">Patient Name</th>
                       <th scope="col" className="buttonFont">Mobile No</th>
                       <th scope="col" className="buttonFont">Doctor Name</th>
                       <th scope="col" className="buttonFont">Speciality</th>
                       <th scope="col" className="buttonFont">Hospital Name</th>
                       <th scope="col" className="buttonFont">Appointment<br/> Date</th>
                       <th scope="col" className="buttonFont">Actions</th>
                      
                   </tr>
               </thead>
               <tbody>
                   <tr>
                       <th scope="row"> 1</th>
                       <td>Dixth</td>
                       <td>9676046060</td>
                       <td>Rohit</td>
                       <td>orthopedic</td>
                       
                       <td>Kims</td>
                       <td>10/11/2020</td>
                       <td>
                       <a className="btn text-primary" onClick={()=>{setUpdate(true)}}>
                                <i className="fas fa-pencil-alt"></i>
                            </a>
                            <a className="btn text-danger" >
                                <i className="fas fa-trash-alt"></i>
                            </a>  
                       </td>
                   </tr>
               </tbody>
           </table>
       </div>
    
   )

   
    }