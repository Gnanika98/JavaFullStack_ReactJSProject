
import React,{useState} from 'react';

import {BrowserRouter as Router, Route, Link,useHistory,Redirect} from 'react-router-dom'
//import DoctorList from './DoctorList';



export default function  ViewDoctors(){ 

    const [state, setstate] = useState(false)
    const history = useHistory();

    const handleSubmit = e =>{
        e.preventDefault();
      history.push("/DoctorList");
      
    }
    

    return( 
        
             <div class="col-md-6 card" id="card-card">
                <div class="card-body">
                
            <form onSubmit={handleSubmit}>
            <div class="form-group">
             <h5 class="header-color"><b>Check Doctors based on speciality...</b></h5>
            </div> 
            <div class="form-group">
             <label><b>Speciality</b></label>
             <input type="text" class="form-control" id="speciality"
             pattern="^[a-zA-Z]{4,15}"
             title="Only alphabets allowed 4 - 15 letters" required/>
            </div> 
            <div class="form-group">          
             <label ><b>Location</b></label>
             <input type="text" class="form-control" id="location"
             pattern="^[a-zA-Z]{4,15}"
             title="Only alphabets allowed 4 - 15 letters" required/>
            </div> 
            <div class="button">
           
            <button type="submit" class="btn buttonFont btn-block" style={{backgroundColor:"mediumvioletred"}}>Submit</button>
        
            </div>
            </form>
            </div>
            </div>
            
        
        )
    }

    //<Route exact path="/doctorList" component={DoctorList} />
    //