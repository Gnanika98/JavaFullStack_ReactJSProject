import React,{useState} from 'react';
import './ViewFeedbaks.css'; 
import {FcRating} from "react-icons/fc";

export default function  ViewFeedbacks(){

    return (

        <div class="container">
          <div class="col-md-7">
                <div class="card" id="rating-card">
                <div class="card-body-rating"> 
                <div class="group">
                 <h5><FcRating/>&nbsp;&nbsp;chandu</h5>
                 <h5>Rating : 6</h5>
                </div>
                </div>
                </div>
                </div>
                <div class="col-md-7">
                <div class="card" id="rating-card">
                <div class="card-body-rating"> 
                <div class="group">
                <h5><FcRating/>&nbsp;&nbsp;thanish</h5>
                <h5>Rating : 7</h5>
                </div>
                </div>
                </div>
            </div>
            </div>

    )
}