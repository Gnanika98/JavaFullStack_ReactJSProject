
import React,{useState} from 'react';

export default function  AddAppointment(){ 

  const [state, setstate] = useState(false)

    if(state){
        return <h4>Booking successfull</h4>    
    }


    return( 
     <div class="container">
         
         <div class="col-md-6"> 
         <div class="card">
         <div class="card-body" > 
         <form >
         <div class="form-group">
             <h5 class="header-color"><b>Book Appointment...</b></h5>
            </div> 
            <div class="form-group">
             <label><b>Patient Name</b></label>
             <input type="text" class="form-control" id="patientName" pattern="^[a-zA-Z]+$"
              title="Only alphabets allowed" required/>
            </div> 
            <div class="form-group">
                        
             <label ><b>Mobile Number</b></label>
             <input type="number" class="form-control" id="mobileNo"  
             pattern="^[6-9]{1}[0-9]{9}"
             title="it contain 10 digits start with 6,7,8,9" required/>
             
            </div> 
            
            <div class="form-group">
             <label><b>Appointment date</b></label><br/>
             <input type="date"
             min="2020-10-01"
             max="2020-10-31"
             name="appointmentDate" required/>
            
            </div>
          <div class="button">
            
            <button class="btn buttonFont btn-block" type="submit" style={{backgroundColor:"mediumvioletred"}}>Book</button>
            
          </div>
          </form>
          </div>
          </div>
          </div>
     </div>

    )
}