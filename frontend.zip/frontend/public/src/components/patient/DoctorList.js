import React,{useState} from 'react';
//import AddAppointment from './AddAppointment';

import {FaStar,FaBookMedical} from "react-icons/fa";
import {FcRating,FcVoicePresentation} from "react-icons/fc";
import ViewFeedbacks from './ViewFeedbacks';
import {BrowserRouter as useHistory,Redirect} from 'react-router-dom'

 
export default function DoctorList(){  
    const [state, setstate] = useState(false)
    const [stateRating, setRating] = useState('')


    var handleClick = () => {
        
         setRating(prompt("Please give rating to doctor from 1 - 9 ? "))
    
}
    if(state){
        return <Redirect to="/AddAppointment" />
    }
    return(
       
        <div>
         <table className="table table-striped">
         <thead className="thead" style={{background: " rgb(189, 20, 127)"}}>
                    <tr>
                        <th scope="col" className="buttonFont">Doctor Id</th>
                        <th scope="col" className="buttonFont">Doctor Name</th>
                        <th scope="col" className="buttonFont">Speciality</th>
                        <th scope="col" className="buttonFont">Location</th>
                        <th scope="col" className="buttonFont">Hospital Name</th>
                        <th scope="col" className="buttonFont">Mobile Number</th>
                        <th scope="col" className="buttonFont">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row"> 1</th>
                        <td>Srinu</td>
                        <td>orthopedic</td>
                        <td>Yasoda</td>
                        <td>Begumet</td>
                        <td>9676046060</td>
                        <td>
                        <a className="btn text-primary " onClick={()=>{setstate(true)}}>
                        <h4><FaBookMedical/></h4>
                            </a>
                            <a className="btn" data-toggle="modal" data-target="#addrating" >
                            <h4><FcVoicePresentation/></h4>
                            </a>
                            
                            <a className="btn text-primary" onClick={handleClick}>
                            <h4><FcRating /></h4>
                            </a> 
                           

                            </td>
                        
                    </tr>
                </tbody>
            </table>
            <div class="modal fade" id="addrating" tabindex="-1" aria-labelledby="updateDoctorModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content rating">
            <div class="modal-body" id="updateModal">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
             <ViewFeedbacks/>
        </div>
        </div>
        </div>
        </div>
        </div>
        
    )
}

