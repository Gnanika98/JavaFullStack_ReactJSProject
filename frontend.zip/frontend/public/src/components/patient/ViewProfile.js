import React, { useState } from 'react'
import UpadateProfile from './UpdateProfile'

export default function ViewProfile() {
    const [profile, ViewProfile] = useState(false);
   
if(profile){
return <UpadateProfile/>
}
    return (
       
         <div class="container">
         <div class="col-md-7">
           <div class="card">
             <div class="card-body" >
               <form>
                 <div class="form-group">
                   <h4 class="header-color"><b>Profile</b> </h4>
                   <a className="btn text-primary" onClick={()=>{ViewProfile(true)}}>
                 <i className="fas fa-pencil-alt"></i>
                          </a>
                   <hr />
                 </div>
                 <div class="form-group">
                        <label><b>Patient ID*</b></label><br />
                        <input type="text" value=""
                            className="form-control"
                            id="patientId" disabled />
                    </div>
                 <div class="form-group">
                   <label><b>Full Name*</b></label>
                   <input type="text" class="form-control" id="patientName"
                     disabled />
                 </div>
                 <div class="form-group">
   
                   <label><b>Mobile Number*</b></label>
                   <input type="text" class="form-control" id="mobileNo"
                      disabled />
   
                 </div>
                 <div class="form-group">
                   <label><b>Email address*</b></label>
                   <input type="email" class="form-control" id="email" disabled />
                 </div>
                 <div class="form-group">
                   <label><b>Password*</b></label>
                   <input type="password" class="form-control" id="password"
                     
                     disabled />
                 </div>
                 <div class="form-group form-check">
                   <label id="check-box"><b>Gender :</b> &nbsp;&nbsp;</label>
                   <input type="radio" name="gender" value="Male" id="check" disabled/>&nbsp;Male&nbsp;&nbsp;&nbsp;&nbsp;
                 <input type="radio" name="gender" value="Female" id="check" disabled/>&nbsp;Female
                 </div>
   
                 <div class="form-group form-check">
                   <label for="checkbox" id="check-box"><b>Blood group :</b> &nbsp;&nbsp;</label>
                   <input type="radio" name="blood group" value="A+" id="check1" disabled/>&nbsp;A+&nbsp;&nbsp;
     <input type="radio" name="blood group" value="A-" id="check1" disabled/>&nbsp;A-&nbsp;&nbsp;
     <input type="radio" name="blood group" value="B+" id="check1" disabled />&nbsp;B+&nbsp;&nbsp;
     <input type="radio" name="blood group" value="B-" id="check1" disabled/>&nbsp;B-&nbsp;&nbsp;
     <input type="radio" name="blood group" value="O+" id="check1" disabled/>&nbsp;O+&nbsp;
     <input type="radio" name="blood group" value="O-" id="check1" disabled/>&nbsp;O-
    </div>
   
                 <div class="form-group">
                   <label><b>Age*</b></label>
                   <input type="text" class="form-control" id="age"
                      disabled />
   
                 </div>
                 <div class="form-group">
                   <label><b>Address*</b></label><br />
                   <textarea name="address" id="addres" rows="2" col="15"
                     class="form-control"
                      disabled />
   
                 </div>
                
               </form>
             </div>
           </div>
         </div>
       </div>
    )
}
