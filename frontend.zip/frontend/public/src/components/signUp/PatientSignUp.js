
import React, { useState, useEffect } from 'react';
import "./PatientSignUp.css"
import { useHistory } from 'react-router-dom';

const axios = require('axios').default;
export default function PatientSignUp() {

    const patientDetails = {
        patientName: "",
        mobileNo: "",
        email: "",
        password: "",
        bloodGroup: "",
        gender: "",
        age: "",
        address: ""

    }
    const [patient, setPatient] = useState(patientDetails);
    const [message, setMessage] = useState("");
    const history = useHistory();
    const handleInput = (e) => {
        var { name, value } = e.target;
        setPatient({
            ...patient,
            [name]: value
        })
    }
    useEffect(() => {
        axios.post('http://localhost:8080/addpatient', patient).then((response) => {
            setMessage(response.data.message);
        })
    }, [patient])
    const handleSubmit = e => {
        e.preventDefault();

        if (message === "Patient Added succesfully") {
            alert("Registered successfully")
            history.push('/')
            setTimeout("location.reload(true)");
        } else {
            alert("not registered");
        }

    }

    return (
        <div class="container">

            <div class="modal fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content patientContent">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"> <i class="fas fa-user-injured mr-2"></i>Patient Registration</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body" >

                            <form
                                // autoComplete="off" 
                                action="" onSubmit={handleSubmit}>


                                <div class="form-group">
                                    <label><b>Full Name*</b></label>
                                    <input type="text" class="form-control" id="patientName" pattern="^[a-zA-Z]+$"
                                        title="Only alphabets allowed"
                                        name="patientName"
                                        value={patient.patientName}
                                        onChange={handleInput}
                                        required />
                                </div>

                                <div class="form-group">
                                    <label ><b>Mobile Number*</b></label>
                                    <input type="number" class="form-control" id="mobileNo"
                                        // pattern="^[6-9][0-9]{9}"
                                        // title="Mobile Number Starts with 6,7,8,9 and contains only 10 digits"
                                        name="mobileNo"
                                        value={patient.mobileNo}
                                        onChange={handleInput}
                                        required />

                                </div>
                                <div class="form-group">
                                    <label><b>Email address*</b></label>
                                    <input type="email" class="form-control" id="email"
                                        name="email"
                                        value={patient.email}
                                        onChange={handleInput}
                                        required />
                                </div>
                                <div class="form-group">
                                    <label ><b>Password*</b></label>
                                    <input type="password" class="form-control" id="password"
                                        // pattern="^[A-Za-z]\w{7,14}$"
                                        // title="password should contain one special character and minimum 8 characters"
                                        name="password"
                                        value={patient.password}
                                        onChange={handleInput}
                                        required />
                                </div>

                                <div class="form-group">
                                    <label ><b>gender*</b></label>
                                    <input type="text" class="form-control" id="gender"
                                        // pattern="^[A-Za-z]\w{7,14}$"
                                        // title="password should contain one special character and minimum 8 characters"
                                        name="gender"
                                        value={patient.gender}
                                        onChange={handleInput}
                                        required />
                                </div>

                                <div class="form-group">
                                    <label ><b>bloodGroup*</b></label>
                                    <input type="text" class="form-control" id="bloodGroup"
                                        // pattern="^[A-Za-z]\w{7,14}$"
                                        // title="password should contain one special character and minimum 8 characters"
                                        name="bloodGroup"
                                        value={patient.bloodGroup}
                                        onChange={handleInput}
                                        required />
                                </div>

                                {/* <div class="form-group form-check">
                                    <label id="check-box"><b>Gender :</b> &nbsp;&nbsp;</label>
                                    <input type="radio" name="gender" value={patient.gender}
                                        onChange={handleInput} id="check" />&nbsp;<b>Male</b>&nbsp;&nbsp;&nbsp;&nbsp;
                                    <input type="radio" name="gender" value={patient.gender}
                                        onChange={handleInput} id="check" />&nbsp;<b>Female</b>
                                </div> */}

                                {/* <div class="form-group form-check">
                                    <label for="checkbox" id="check-box"><b>Blood group :</b> &nbsp;&nbsp;</label>
                                    <input type="radio" name="bloodGroup" value={patient.bloodGroup}
                                        onChange={handleInput} id="check1" />&nbsp;A+&nbsp;&nbsp;
                                    <input type="radio" name="bloodGroup" value={patient.bloodGroup}
                                        onChange={handleInput} id="check1" />&nbsp;A-&nbsp;&nbsp;
                                    <input type="radio" name="bloodGroup" value={patient.bloodGroup}
                                        onChange={handleInput} id="check1" />&nbsp;B+&nbsp;&nbsp;
                                    <input type="radio" name="bloodGroup" value={patient.bloodGroup}
                                        onChange={handleInput} id="check1" />&nbsp;B-&nbsp;&nbsp;
                                    <input type="radio" name="bloodGroup" value={patient.bloodGroup}
                                        onChange={handleInput} id="check1" />&nbsp;O+&nbsp;&nbsp;
                                    <input type="radio" name="bloodGroup" value={patient.bloodGroup}
                                        onChange={handleInput} id="check1" />&nbsp;O-
                                </div> */}

                                <div class="form-group">
                                    <label ><b>Age*</b></label>
                                    <input type="number" class="form-control" id="age"
                                        pattern="[1-9]{1}[0-9]{2}"
                                        title="Age between 1 to 130"
                                        name="age"
                                        value={patient.age}
                                        onChange={handleInput}
                                        required />

                                </div>
                                <div class="form-group">
                                    <label><b>Address*</b></label><br />
                                    <textarea name="address" id="address" pattern="^[A-Za-z]\w{5,100}$"
                                        title="Range between 5 to 100 "
                                        name="address"
                                        value={patient.address}
                                        onChange={handleInput}
                                        required />

                                </div>
                                <div class="button">

                                    <button class="btn buttonFont btn-block" type="submit"
                                        style={{ backgroundColor: "mediumvioletred" }}>Submit</button>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}