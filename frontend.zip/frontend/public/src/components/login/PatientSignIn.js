import React from 'react'
// import { useHistory } from 'react-router-dom';


export default function PatientSignIn() {
// const history = useHistory();
//   var handleSubmit = e=>{
//     e.preventDefault();
//     history.push('/PatientSidebar')
//     // setTimeout("location.reload(true)");
//   }

    return (
      <form action="/PatientSidebar">
        <div className="inner-container">
          <div className="header">
            <i class="fas fa-user-injured mr-2"></i>Patient login
          </div>
          <div className="box">
  
            <div className="input-group">
              <label htmlFor="email">Email</label>
              <input
                type="email"
                name="email"
                className="login-input"
                placeholder="email"
                required/>
            </div>
  
  
            <div className="input-group">
              <label htmlFor="password">Password</label>
              <input
                type="password"
                name="password"
                pattern="^[A-Za-z]\w{7,14}$"
                title="password should contain minimum 7 characters"
                className="login-input"
                placeholder="password"/>
            </div>
            <button
              type="submit"
              className="login-btn"
              
              >Login</button>
          </div>
        </div>
        </form>
    )
}
