import React from 'react'

export default function DoctorForgetPassword() {
    return (
        <div>
            <form name="DoctorForgetPasswordForm">
                <input type="text" />
            </form>
        </div>
    )
}
